package com.communityLib.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.communityLib.domain.Book;
import com.communityLib.domain.BookAuthor;
import com.communityLib.domain.BookRequest;
import com.communityLib.domain.User;
import com.communityLib.service.BookAuthorSearch;
import com.communityLib.service.BookRequestSearch;
import com.communityLib.service.BookSearch;
import com.communityLib.service.LoginService;

@Controller
public class CommLibController {

	private String errMessage = "Invalid login Credentials!!!";
	private String successMessage = "The book is successfully added to the repository!!!";
	Map<String, Object> model;
	@Autowired
	LoginService loginService;
	@Autowired
	BookSearch bookSearch;
	@Autowired
	BookAuthorSearch bookAuthorSearch;

	@Autowired
	BookRequestSearch bookRequestSearch;

	/**
	 * @param model
	 * @return
	 */
	@RequestMapping("/")
	public String welcome(Map<String, Object> model) {

		User user = new User();
		user.setFirstname("sri");
		user.setLastname("vidhya");
		user.setAddress1("pallavaram");
		user.setAddress2("chennai");
		user.setPassword("test");
		user.setUserAdmin(false);
		user.setUserType("D");
		user.setUserZip("600043");
		user.setUserName("donaruser");
		loginService.save(user);
		user = new User();
		user.setFirstname("jayanthi");
		user.setLastname("jayram");
		user.setAddress1("Adyar");
		user.setAddress2("chennai");
		user.setPassword("test");
		user.setUserAdmin(false);
		user.setUserType("R");
		user.setUserZip("600003");
		user.setUserName("Receiveuser");
		loginService.save(user);
		user = new User();
		user.setFirstname("lakshmi");
		user.setLastname("divya");
		user.setAddress1("siruseri");
		user.setAddress2("chennai");
		user.setPassword("admin");
		user.setUserAdmin(false);
		user.setUserType("A");
		user.setUserZip("600003");
		user.setUserName("Admin");
		loginService.save(user);

		return "login";
	}

	/**
	 * 
	 * @param uname
	 * @param pwd
	 * @param model
	 * @return
	 */

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(@RequestParam("username") String uname, @RequestParam("password") String pwd,
			Map<String, Object> model) {
		List<User> users = loginService.findByUserName(uname);
		String page = "welcome";
		for (User user : users) {
			if (loginService.validate(user, pwd)) {

				String type = user.getUserType();

				if (type.equalsIgnoreCase("R"))
					page = "bookRequestor";
				else if (type.equalsIgnoreCase("D"))
					page = "donor";
				else
					page = "admin";
				model.put("message", this.errMessage);

			} else {
				model.put("message", this.errMessage);
				page = "login";
			}

		}
		model.put("firstLoad", "first");
		return page;
	}

	/**
	 * @param isbnNo
	 * @param bookTitle
	 * @param academicClass
	 * @param genre
	 * @param publisher
	 * @param authorName
	 * @param publishYear
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/donor", method = RequestMethod.POST)
	public String donor(@RequestParam("bookIsbnno") long isbnNo, @RequestParam("bookTitle") String bookTitle,
			@RequestParam("academicClass") String academicClass, @RequestParam("genre") String genre,
			@RequestParam("publisher") String publisher, @RequestParam("authorName") String authorName,
			@RequestParam("publishYear") String publishYear, Map<String, Object> model) {
		// Map<String,String> model;
		Book book = new Book();
		BookAuthor author = new BookAuthor();
		book.setBookIsbnno(isbnNo);
		book.setBookTitle(bookTitle);
		book.setAcademicClass(academicClass);
		book.setGenre(genre);
		book.setPublisher(publisher);
		book.setPublishYear(publishYear);
		bookSearch.addBook(book);

		author.setBookIsbnno(isbnNo);
		author.setAuthorName(authorName);
		bookAuthorSearch.addBookAuthor(author);
		model.put("successMessage", this.successMessage);
		return "donor";
	}

	/**
	 * @param bookTitle
	 * @param genre
	 * @param bookIsbnno
	 * @param authorName
	 * @param availableStatus
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/search", method = RequestMethod.POST)
	public String searchBooks(@RequestParam("bookTitle") String bookTitle, @RequestParam("genre") String genre,
			@RequestParam("bookIsbnno") String bookIsbnno, @RequestParam("authorName") String authorName,
			@RequestParam("availableStatus") String availableStatus, Map<String, Object> model) {
		String page = "bookRequestor";
		Book searchBook = new Book();
		List<Book> lstBook = new ArrayList<Book>();

		if (bookTitle != null && !(bookTitle.trim().isEmpty())) {
			lstBook = bookSearch.findByTitle(bookTitle);
			model.put("book", lstBook);
		} else if (null != bookIsbnno && (bookIsbnno.trim().length() > 1)) {

			bookIsbnno = bookIsbnno.substring(0, bookIsbnno.length() - 2);

			searchBook = bookSearch.findByISBN(Long.parseLong(bookIsbnno));
			lstBook.add(searchBook);
			model.put("book", lstBook);
		} else if (null != genre && !(genre.trim().isEmpty())) {
			lstBook = bookSearch.findByGenre(genre);
			model.put("book", lstBook);
		} else if (null != authorName && !(authorName.trim().isEmpty())) {
			lstBook = bookAuthorSearch.findByAuthorName(authorName);
			model.put("book", lstBook);
		} else if (null != availableStatus && !(availableStatus.trim().isEmpty())) {
			lstBook = bookSearch.findByAvailabilityStatus();
			model.put("book", lstBook);
		} 

		page = "bookRequestor";
		return page;
	}

	/**
	 * @param bookIsbnno
	 * @param model
	 * @return
	 */
	/**
	 * @param bookIsbnno
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/requestBook", method = RequestMethod.GET)
	public String requestBook(@RequestParam("bookIsbnno") String bookIsbnno, Map<String, Object> model) {
		Book searchBook = bookSearch.findByISBN(Long.parseLong(bookIsbnno));
		BookRequest bookReq = new BookRequest();
		bookReq.setBookId(searchBook.getBookId());
		bookReq.setRequestDate(new Date());
		bookReq.setReqStatus("p");
		bookRequestSearch.addBookReq(bookReq);
		model.put("reqMsg", "success");
		String page = "bookRequestor";
		return page;
	}

}
