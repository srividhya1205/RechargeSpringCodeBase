package com.communityLib.service;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.communityLib.domain.Book;
import com.communityLib.domain.BookAuthor;

@Service
public class BookAuthorSearchImpl implements BookAuthorSearch{
	@Autowired
	BookAuthorSearchRepository bookAuthorSearchRepository;
	@Autowired
	BookSearchRepository bookSearchRepository;

	/* (non-Javadoc)
	 * @see com.communityLib.service.BookAuthorSearch#findByAuthorName(java.lang.String)
	 */
	@Override
	public List<Book> findByAuthorName(String author){
		List<Book> BookListByAuthor=new ArrayList<Book>();
		Book tempBook=new Book();
		List<BookAuthor> lstIsbn =  bookAuthorSearchRepository.findByAuthorName(author);
		
	for (BookAuthor bookAuthor : lstIsbn) {
		
			tempBook= bookSearchRepository.findByBookIsbnno(bookAuthor.getBookIsbnno());
			
			BookListByAuthor.add(tempBook);
		}
			Consumer<Book> bookCons = (book)-> System.out.println(book);
			for (Book book2 : BookListByAuthor) {
				bookCons.accept(book2);
			}
			return BookListByAuthor;
		
	}
	/* (non-Javadoc)
	 * @see com.communityLib.service.BookAuthorSearch#addBookAuthor(com.communityLib.domain.BookAuthor)
	 */
	@Override
	public void addBookAuthor(BookAuthor author) {
		bookAuthorSearchRepository.save(author);

	}



}
