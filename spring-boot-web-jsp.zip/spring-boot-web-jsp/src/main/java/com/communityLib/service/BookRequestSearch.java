package com.communityLib.service;

import com.communityLib.domain.BookRequest;

public interface BookRequestSearch {
	
	public void addBookReq(BookRequest bookReq1);
}
