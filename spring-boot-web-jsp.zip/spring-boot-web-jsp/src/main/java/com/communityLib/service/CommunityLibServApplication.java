package com.communityLib.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;

import com.communityLib.domain.Book;
import com.communityLib.domain.BookAuthor;
import com.communityLib.domain.BookRequest;
import com.communityLib.domain.User;

@SpringBootApplication(scanBasePackages={"com.communityLib.*"})
@EntityScan(basePackageClasses={Book.class,BookAuthor.class,User.class,BookRequest.class})
public class CommunityLibServApplication implements CommandLineRunner {
	
	@Autowired
	ApplicationContext myApplnContext;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(CommunityLibServApplication.class,args);
	}

	/* (non-Javadoc)
	 * @see org.springframework.boot.CommandLineRunner#run(java.lang.String[])
	 */
	@Override
	public void run(String... arg0) throws Exception {
	}
	

}
