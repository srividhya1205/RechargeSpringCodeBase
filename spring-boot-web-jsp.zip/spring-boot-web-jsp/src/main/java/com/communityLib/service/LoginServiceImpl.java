package com.communityLib.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.communityLib.domain.User;
@Service
public class LoginServiceImpl implements LoginService{

	@Autowired
	LoginRepository loginRepository;
	
	@Override
	public List<User> findByUserName(String name) {

		List<User> users =  loginRepository.findByUserName(name);
			return users;
	}

	/* (non-Javadoc)
	 * @see com.communityLib.service.LoginService#validate(com.communityLib.domain.User, java.lang.String)
	 */
	@Override
	public boolean validate(User user,String pwd) {
		// TODO Auto-generated method stub
		boolean flag=false;
		if(user.getPassword().equalsIgnoreCase(pwd))
			flag= true;
		return flag;
		
	}

	/* (non-Javadoc)
	 * @see com.communityLib.service.LoginService#save(com.communityLib.domain.User)
	 */
	@Override
	public String save(User user) {
		// TODO Auto-generated method stub
		loginRepository.save(user);
		return "success";
	}

	/* (non-Javadoc)
	 * @see com.communityLib.service.LoginService#getUser(java.lang.String)
	 */
	@Override
	public User getUser(String id) {
		// TODO Auto-generated method stub
		return loginRepository.findOne(id);
		
	}
	
	

}
