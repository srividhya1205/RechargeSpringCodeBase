package com.communityLib.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.communityLib.domain.BookRequest;

@Service
public class BookRequestSearchImpl implements BookRequestSearch {

	@Autowired
	BookRequestRepository bookRequestRepository;
	
	/* (non-Javadoc)
	 * @see com.communityLib.service.BookRequestSearch#addBookReq(com.communityLib.domain.BookRequest)
	 */
	public void addBookReq(BookRequest book) {
		bookRequestRepository.save(book);
	}

	

}
