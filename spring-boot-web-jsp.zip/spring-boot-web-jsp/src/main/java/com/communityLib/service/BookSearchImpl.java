package com.communityLib.service;

import java.util.List;
import java.util.function.Consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.communityLib.domain.Book;

@Service
public class BookSearchImpl implements BookSearch {

	@Autowired
	BookSearchRepository bookSearchRepository;
	
	/* (non-Javadoc)
	 * @see com.communityLib.service.BookSearch#findByTitle(java.lang.String)
	 */
	@Override
	public  List<Book> findByTitle(String title) {
		List<Book> lstBook =	bookSearchRepository.findByBookTitleContaining(title);

		return lstBook;

	}
	/* (non-Javadoc)
	 * @see com.communityLib.service.BookSearch#findByISBN(long)
	 */
	@Override
	public Book findByISBN(long isbnNo) {
	Book book =	bookSearchRepository.findByBookIsbnno(isbnNo);
	
		return book;
	}
	

	/* (non-Javadoc)
	 * @see com.communityLib.service.BookSearch#findByAcademicClass(java.lang.String)
	 */
	@Override
	public List<Book> findByAcademicClass(String academicClass) {
		List<Book> lstBook=	bookSearchRepository.findByAcademicClass(academicClass);
		Consumer<Book> bookCons = (book)-> System.out.println(book);
		for (Book book2 : lstBook) {
			bookCons.accept(book2);
		}
			return lstBook;
		}
	

	/* (non-Javadoc)
	 * @see com.communityLib.service.BookSearch#findByGenre(java.lang.String)
	 */
	@Override
	public List<Book> findByGenre(String genre) {
	List<Book> lstBook=	bookSearchRepository.findByGenre(genre);
	showBooks(lstBook);
		return lstBook;
	}

	/* (non-Javadoc)
	 * @see com.communityLib.service.BookSearch#findByAvailabilityStatus()
	 */
	@Override
	public List<Book> findByAvailabilityStatus() {
		List<Book> lstBook=	bookSearchRepository.findByAvailableStatus(true);
		showBooks(lstBook);
			return lstBook;
	}
	/* (non-Javadoc)
	 * @see com.communityLib.service.BookSearch#addBook(com.communityLib.domain.Book)
	 */
	@Override
	public void addBook(Book book) {
		bookSearchRepository.save(book);
		
	}

	
/**
 * @param lstBook
 */
private void showBooks(List<Book> lstBook)
{
	Consumer<Book> bookCons = (book)-> System.out.println(book);
	for (Book book2 : lstBook) {
		bookCons.accept(book2);
	}
}
}
