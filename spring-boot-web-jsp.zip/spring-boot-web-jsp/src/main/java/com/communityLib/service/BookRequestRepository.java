package com.communityLib.service;

import org.springframework.data.repository.CrudRepository;

import com.communityLib.domain.Book;
import com.communityLib.domain.BookRequest;

public interface BookRequestRepository extends CrudRepository<Book, String> {

	public void save(BookRequest book);	

}
