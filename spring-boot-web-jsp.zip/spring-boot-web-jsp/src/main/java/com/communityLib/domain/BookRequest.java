package com.communityLib.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="book_request",catalog="CommunityLibrary")
public class BookRequest implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2553206037823764014L;
	private long reqId;	
	private long bookId;	
	private int	reqByUser;         
	private Date requestDate ;
	private  String reqStatus;
	
	
	public BookRequest(){
		
	}
	
   @Id
   @Column(name="book_id",unique=true,nullable= false)
	public long getBookId() {
		return bookId;
	}

	public void setBookId(long bookId) {
		this.bookId = bookId;
	}
	
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 @Column(name="request_id",unique=true,nullable= false)
		public long getRequestId() {
			return reqId;
		}

		public void setRequestId(long reqId) {
			this.reqId = reqId;
		}

	@Column(name="requested_user")
	public int getReqByUser() {
		return reqByUser;
	}

	public void setReqByUser(int reqByUser) {
		this.reqByUser = reqByUser;
	}

	@Column(name="request_date")
	public Date getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(Date reqOn) {
		this.requestDate = reqOn;
	}
	
	@Column(name="request_status")
	public String getReqStatus() {
		return reqStatus;
	}

	public void setReqStatus(String reqStatus) {
		this.reqStatus = reqStatus;
	}

	
	
	
	
}
